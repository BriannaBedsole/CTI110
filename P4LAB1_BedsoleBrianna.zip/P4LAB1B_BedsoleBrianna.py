#Brianna Bedsole
#11/10/2024
#P4LAB1 B
#In this assignment we will be using turtle graphics to write our initals.
import turtle

def draw_initials():
    t = turtle.Turtle()
    t.pensize(5)
    t.color("Purple")
    t.speed(3)

    def draw_B():
        t.forward(120)
        t.backward(120)
        
        t.right(90)
        t.forward(20)
        t.circle(30, 180)
        
        t.forward(20)
        
        t.right(180)
        t.forward(20) 
        t.circle(30, 180)
        t.forward(20)

    t.penup()
    t.goto(-100, 60)
    t.setheading(90)
    t.pendown()
    
    draw_B()
    
    t.penup()
    t.goto(0, 60)
    t.setheading(90)
    t.pendown()
    
    draw_B()

    t.hideturtle()
    turtle.done()

draw_initials()
